package trabalho;

/**
	*
	*@author JoãoVitorAntoniassiSegantin
	*
*/


public class Inicio
{
	/**
		*@param args não trabalha com argumentos
	*/
	public static void main(String args[])
	{
		new Janela();
	}
}
