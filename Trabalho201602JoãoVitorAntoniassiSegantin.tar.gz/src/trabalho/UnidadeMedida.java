package trabalho;
/**
	*
	*@author JoãoVitorAntoniassiSegantin
	*
*/
public enum UnidadeMedida
{
	m, kg, un;
}
